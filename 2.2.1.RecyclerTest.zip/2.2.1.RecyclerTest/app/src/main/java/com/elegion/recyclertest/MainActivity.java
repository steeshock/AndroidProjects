package com.elegion.recyclertest;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements ContactsAdapter.OnItemClickListener, LoaderManager.LoaderCallbacks<String> {
    public static final String TAG = "TAG" ;



    private Loader<String> mLoader;
    private Bundle mBundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, RecyclerFragment.newInstance())
                    .commit();
        }
    }

    @Override
    public void onItemClick(String id) {

        mBundle = new Bundle();
        mBundle.putString(MyLoader.ID, id);
        mLoader = getLoaderManager().restartLoader(0, mBundle, this);
        mLoader.forceLoad();
    }

    @Override
    public Loader<String> onCreateLoader(int id, Bundle args) {

        Log.d(TAG, "onCreateLoader: ");
        Log.d(TAG, "args: " + args);

        return new MyLoader(this, args);
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data) {

        Log.d(TAG, "onLoadFinished: ");


        if (data != null){
            startActivity(new Intent(Intent.ACTION_CALL).setData(Uri.parse("tel:" + data)));
        } else {
            Toast.makeText(this, "Error!", Toast.LENGTH_SHORT).show();
        }

        loader.stopLoading();
    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.menu_item:

                if (mLoader != null && mLoader.isStarted()){


                        mLoader.cancelLoad();
                        mLoader.stopLoading();
                        Toast.makeText(this, "Запрос отменен", Toast.LENGTH_SHORT).show();

                }
                break;
            default: break;
        }

        return super.onOptionsItemSelected(item);

    }
}
