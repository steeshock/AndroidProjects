package com.elegion.recyclertest;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

/**
 * Created by steeshock on 10.05.2018.
 */

public class MyLoader extends android.content.AsyncTaskLoader<String> {

    public String id;
    public String number;
    public static final String  ID = "ID";

    public MyLoader(Context context, Bundle args) {
        super(context);

        if (args != null)
            id = args.getString(ID);
    }


    @Override
    public String loadInBackground() {

       try{
           TimeUnit.SECONDS.sleep(3);
       } catch (InterruptedException e) {
           Log.d(MainActivity.TAG, e.getLocalizedMessage());
       }

        Cursor cursor = getContext().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? AND "
                        + ContactsContract.CommonDataKinds.Phone.TYPE + " = ?",
                new String[]{id, String.valueOf(ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)},
                null);

        if (cursor != null && cursor.moveToFirst()) {
            number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            cursor.close();

            return number;
        } else return null;
    }

    @Override
    public void forceLoad() {
        super.forceLoad();

        Log.d(MainActivity.TAG, "forceLoad: ");
    }

    @Override
    protected boolean onCancelLoad() {

        Log.d(MainActivity.TAG, "onCancelLoad: ");
        return super.onCancelLoad();
    }
}
