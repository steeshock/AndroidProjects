package ru.steeshock.asynctaskloadersample;

import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<String> {

    public static final String LOG_TAG = "my_tag";
    private TextView mResultTxt;
    private Bundle mBundle;
    public static final int LOADER_RANDOM_ID = 1;
    private Loader<String> mLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mResultTxt = findViewById(R.id.resultTxt);

        mBundle = new Bundle();
        mBundle.putString(RandomLoader.ARG_WORD, "test");
        mLoader = getSupportLoaderManager().initLoader(LOADER_RANDOM_ID, mBundle, this);
        //getLoaderManager().initLoader(LOADER_RANDOM_ID, mBundle, this);
    }

    public Loader<String> onCreateLoader(int id, Bundle args) {
        Loader<String> mLoader = null;
        // условие можно убрать, если вы используете только один загрузчик
        if (id == LOADER_RANDOM_ID) {
            mLoader = new RandomLoader(this, args);
            Log.d(LOG_TAG, "onCreateLoader");
        }
        return mLoader;
    }

    public void onLoadFinished(Loader<String> loader, String data) {
        Log.d(LOG_TAG, "onLoadFinished");
        mResultTxt.setText(data);
    }

    public void onLoaderReset(Loader<String> loader) {
        Log.d(LOG_TAG, "onLoaderReset");
    }

    public void startLoad(View v) {
        Log.d(LOG_TAG, "startLoad");
        mLoader.onContentChanged();
    }
}
