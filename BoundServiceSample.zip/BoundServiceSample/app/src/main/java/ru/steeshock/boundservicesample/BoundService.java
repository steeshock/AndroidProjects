package ru.steeshock.boundservicesample;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.ProgressBar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class BoundService extends Service {

    public static final String TAG = "myLogs";
    public static final String DONE = "DONE";
    public static int counter = 0;
    public ProgressBar p;
    public ExecutorService executorService;
    MyBinder binder = new MyBinder();

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(BoundService.TAG, "BoundService onBind");
        return binder;
    }

    @Override
    public void onCreate() { executorService = Executors.newSingleThreadExecutor();}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: ");
        return START_STICKY;
    }

    public int getCount() {return counter;}

    public void setCount (int c) {counter = c;}

    public void decreaceCount () {counter = getCount() - 50;}


    public void fillProgressBar () {
        executorService.submit(new Runnable(){
            @Override
            public void run() {
                for (counter = getCount(); counter <=100; counter++){
                    try {
                        if (counter%5 == 0 | counter == 0) {
                            TimeUnit.MILLISECONDS.sleep(200);
                            p.setProgress(counter);
                        }
                        if(counter ==100){
                            sendBroadcast(new Intent(SimpleReceiver.SIMPLE_ACTION));
                            break;
                        }
                    }
                    catch (InterruptedException e){
                        System.out.println (e.getLocalizedMessage());
                    }
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        executorService.shutdownNow();
        Log.d(TAG, "onDestroy.");
    }

    class MyBinder extends Binder {
        BoundService getService() {
            return BoundService.this;
        }
    }

}
