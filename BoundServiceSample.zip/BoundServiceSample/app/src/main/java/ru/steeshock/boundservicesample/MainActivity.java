package ru.steeshock.boundservicesample;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    public Button decrease;
    public Intent intent;
    public BoundService mBoundService;
    public boolean bound = false;
    public TextView textView;
    public ProgressBar progressBar;
    private IntentFilter mIntentFilter;
    private SimpleReceiver mSimpleReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSimpleReceiver = new SimpleReceiver();

        textView = findViewById(R.id.tv_out);
        progressBar = findViewById(R.id.progressBar);

        intent = new Intent(MainActivity.this, BoundService.class);
        mIntentFilter = new IntentFilter(SimpleReceiver.SIMPLE_ACTION);

        decrease = findViewById(R.id.decrease);

        decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mBoundService.getCount() >=50){
                    if (mBoundService.getCount() == 100) {
                        mBoundService.decreaceCount();
                        mBoundService.fillProgressBar();
                    } else {
                        mBoundService.decreaceCount();
                    }
                } else {
                    mBoundService.setCount(0);
                }

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        startService(intent);
        bindService(intent, mServiceConnection, BIND_AUTO_CREATE);

    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mSimpleReceiver, mIntentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mSimpleReceiver);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!bound) return;
        unbindService(mServiceConnection);
        bound = false;
    }

    private ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            Log.d(BoundService.TAG, "MainActivity onServiceConnected");
            mBoundService = ((BoundService.MyBinder) binder).getService();
            bound = true;

            mBoundService.p = findViewById(R.id.progressBar);
            mBoundService.fillProgressBar();

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
        }
    };

}


