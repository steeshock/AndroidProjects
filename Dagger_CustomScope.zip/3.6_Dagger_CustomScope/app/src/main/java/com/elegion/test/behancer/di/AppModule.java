package com.elegion.test.behancer.di;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.content.SharedPreferences;

import com.elegion.test.behancer.AppDelegate;
import com.elegion.test.behancer.common.RefreshOwner;
import com.elegion.test.behancer.data.Storage;
import com.elegion.test.behancer.data.database.BehanceDatabase;
import com.elegion.test.behancer.data.model.user.User;
import com.elegion.test.behancer.ui.profile.ProfileFragment;
import com.elegion.test.behancer.ui.profile.ProfileView;
import com.elegion.test.behancer.ui.projects.ProjectsView;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by tanchuev on 23.04.2018.
 */

@Module
public class AppModule {

    private final AppDelegate mApp;
    private ProfileView mProfileView;

    public AppModule(AppDelegate mApp) {
        this.mApp = mApp;
    }

    @Provides
    @Singleton
    AppDelegate provideApp() {
        return mApp;
    }


    @Provides
    @Singleton
    Context provideContext() {
        return mApp.getApplicationContext();
    }

    /*@Provides
    @Singleton
    ProfileView provideProfileView(Context context) {
        mProfileView = context instanceof ProfileView ? (ProfileView) context : null;
        return mProfileView;
    }*/

    /*@Provides
    @Singleton
    ProfileView provideProfileView() {
        mProfileView = mApp.getBaseContext() instanceof ProfileView ? (ProfileView) mApp.getBaseContext() : null;
        return mProfileView;
    }*/


    @Provides
    @Singleton
    Storage provideStorage() {
        final BehanceDatabase database = Room.databaseBuilder(mApp, BehanceDatabase.class, "behance_database")
                .fallbackToDestructiveMigration()
                .build();

        return new Storage(database.getBehanceDao());
    }
}
