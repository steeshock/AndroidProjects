package com.elegion.test.behancer.di;
import com.elegion.test.behancer.ui.profile.ProfileFragment;

import dagger.Component;

@PerFragment
@Component(modules = {PerFragmentModule.class})
public interface PerFragmentComponent {

    void inject(ProfileFragment injector);

}
