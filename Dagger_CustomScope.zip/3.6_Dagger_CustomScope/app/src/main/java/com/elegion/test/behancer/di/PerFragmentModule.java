package com.elegion.test.behancer.di;

import com.elegion.test.behancer.common.BaseView;
import com.elegion.test.behancer.ui.profile.ProfilePresenter;
import com.elegion.test.behancer.ui.profile.ProfileView;

import dagger.Module;
import dagger.Provides;

@Module
public class PerFragmentModule {

    private BaseView mView;

    public PerFragmentModule(BaseView view){
        mView = view;
    }

    @Provides
    @PerFragment
    public ProfilePresenter provideProfilePresenter(){
        ProfilePresenter profilePresenter = new ProfilePresenter();
        profilePresenter.setView((ProfileView) mView);
        return profilePresenter;
    }
}
