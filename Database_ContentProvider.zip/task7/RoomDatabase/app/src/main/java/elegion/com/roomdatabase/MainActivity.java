package elegion.com.roomdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import elegion.com.roomdatabase.database.Album;
import elegion.com.roomdatabase.database.AlbumSong;
import elegion.com.roomdatabase.database.MusicDao;
import elegion.com.roomdatabase.database.Song;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = "MyLogs";
    private Button mAddBtn;
    private Button mGetBtn;
    public static final int AMOUNT_OF_FIELDS = 5;
    private Random mRandom = new Random();
    public static String ALL = "";


    // добавить базу данных Room ----
    // вставить данные / извлечь данные ---
    // добавить контент провайдер над Room ---

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final MusicDao musicDao = ((AppDelegate) getApplicationContext()).getMusicDatabase().MusicDao();

        mAddBtn = (findViewById(R.id.add));
        mAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                musicDao.insertSongs(createSongs());
                musicDao.insertAlbums(createAlbums());
                musicDao.setLinksAlbumSongs(createLinksAlbumSongs());
            }
        });

        mGetBtn = findViewById(R.id.get);
        mGetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast(musicDao.getAlbums(), musicDao.getSongs(),musicDao.getAlbumSongs());
                Log.d(TAG, ALL);
            }
        });

    }

    private List<Song> createSongs() {
        List<Song> songs = new ArrayList<>();
        for (int i=0;i<AMOUNT_OF_FIELDS;i++){
            songs.add(new Song(i, "song " + i, "duration  " + mRandom.nextInt(100)));
        }
        return songs;
    }

    private List<Album> createAlbums() {
        List<Album> albums = new ArrayList<>();
        for (int i=0;i<AMOUNT_OF_FIELDS;i++){
            albums.add(new Album(i, "album " + i, "release " + System.currentTimeMillis()));
        }
        return albums;
    }

    private List<AlbumSong> createLinksAlbumSongs() {
        List<AlbumSong> albumSongs = new ArrayList<>();
        for (int i=0;i<AMOUNT_OF_FIELDS;i++){
            albumSongs.add(new AlbumSong(mRandom.nextInt(AMOUNT_OF_FIELDS), mRandom.nextInt(AMOUNT_OF_FIELDS)));
        }
        return albumSongs;
    }

    private void showToast(List<Album> albums, List<Song> songs, List<AlbumSong> albumSongs) {

        StringBuilder builder = new StringBuilder();

        for (int i = 0, size = albums.size(); i < size; i++) {
            builder.append(albums.get(i).toString()).append("\n");
        }

        for (int i = 0, size = songs.size(); i < size; i++) {
            builder.append(songs.get(i).toString()).append("\n");
        }

        for (int i = 0, size = albumSongs.size(); i < size; i++) {
            builder.append(albumSongs.get(i).toString()).append("\n");
        }

        ALL = builder.toString();
        Toast.makeText(this, builder.toString(), Toast.LENGTH_LONG).show();

    }
}
