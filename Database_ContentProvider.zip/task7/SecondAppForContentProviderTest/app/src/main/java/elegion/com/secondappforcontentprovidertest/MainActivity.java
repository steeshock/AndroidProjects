package elegion.com.secondappforcontentprovidertest;

import android.Manifest;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    public static final String LOADER_TABLE_NAME = "LOADER_TABLE_NAME";
    public static final String ID = "ID";
    public static final String TAG = "MyLogs";
    private static long TABLE_NAME_ID = 0;
    private Spinner sp_tables, sp_operations;
    private EditText et_id, et1, et2, et3;
    private Button btn_execute;
    public static String TABLE_NAME = "";
    public static String OPERATION_NAME = "";
    private static boolean EMPTY_FIELD= true;
    public static String QUERY_FROM_TABLE = "";
    public static final String [] tables = {
            "album",
            "song",
            "albumsong"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp_tables = findViewById(R.id.sp_table);
        sp_operations = findViewById(R.id.sp_operation);

        et_id = findViewById(R.id.et_id);
        et1 = findViewById(R.id.et_1);
        et2 = findViewById(R.id.et_2);
        et3 = findViewById(R.id.et_3);

        btn_execute = findViewById(R.id.btn_execute);

        sp_operations.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String[] choose = getResources().getStringArray(R.array.operatoins);

                if (TextUtils.isEmpty(et_id.getText()) && (choose[position].equals("delete") || choose[position].equals("update"))) {
                    sp_operations.setSelection(0);
                    Toast.makeText(getApplicationContext(), "Поле ID не должно быть пустым!", Toast.LENGTH_SHORT).show();
                }

                if (choose[position].equals("insert")) {
                    et_id.getText().clear();
                    et_id.setEnabled(false);
                } else et_id.setEnabled(true);

                if (choose[position].equals("update")) {
                    et1.getText().clear();
                    et1.setEnabled(false);
                } else et1.setEnabled(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btn_execute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TABLE_NAME = sp_tables.getSelectedItem().toString();
                TABLE_NAME_ID = sp_tables.getSelectedItemId();
                OPERATION_NAME = sp_operations.getSelectedItem().toString();
                
                if (TextUtils.isDigitsOnly(et_id.getText())) {

                        switch (OPERATION_NAME) {
                            case "query":
                                if (TextUtils.isEmpty(et_id.getText())) {
                                    Cursor c = getContentResolver().query(Uri.parse("content://com.elegion.roomdatabase.musicprovider/" + tables[(int)TABLE_NAME_ID]),
                                            null, null, null, null);
                                    if (c != null && c.moveToFirst()) {
                                        StringBuilder builder = new StringBuilder();
                                        do {
                                            builder.append("id = ").append(c.getString(0)).append(", ").append(c.getString(1)).append(", ").append(c.getString(2)).append("\n");
                                        } while (c.moveToNext());
                                        QUERY_FROM_TABLE = builder.toString();
                                        Toast.makeText(getApplicationContext(), QUERY_FROM_TABLE, Toast.LENGTH_LONG).show();
                                        c.close();
                                    }
                                } else {
                                    Cursor c = getContentResolver().query(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                                    + tables[(int)TABLE_NAME_ID] + "/" + et_id.getText().toString()),
                                            null, null, null, null);

                                    if (c != null && c.moveToFirst()) {
                                        StringBuilder builder = new StringBuilder();
                                        do {
                                            builder.append(c.getString(1)).append(", ").append(c.getString(2));
                                        } while (c.moveToNext());
                                        QUERY_FROM_TABLE = builder.toString();
                                        Toast.makeText(getApplicationContext(), QUERY_FROM_TABLE, Toast.LENGTH_LONG).show();
                                        c.close();
                                    } else Toast.makeText(getApplicationContext(), "Ошибка ID!", Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case "insert":
                                if (sp_tables.getSelectedItem().toString().equals("Albums")) {
                                ContentValues contentValues = new ContentValues();
                                contentValues.put("id", et1.getText().toString());
                                contentValues.put("name", et2.getText().toString());
                                contentValues.put("release", et3.getText().toString());
                                getContentResolver().insert(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                        + tables[(int)TABLE_NAME_ID]), contentValues);
                                break;
                            } else if (sp_tables.getSelectedItem().toString().equals("Songs")) {
                                    ContentValues contentValues = new ContentValues();
                                    contentValues.put("id", et1.getText().toString());
                                    contentValues.put("name", et2.getText().toString());
                                    contentValues.put("duration", et3.getText().toString());
                                    getContentResolver().insert(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                            + tables[(int)TABLE_NAME_ID]), contentValues);
                                    break;
                                } else if (sp_tables.getSelectedItem().toString().equals("AlbumSongs"))
                                    if (idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/album" + "/" + et2.getText().toString())
                                            && idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/song" + "/" + et3.getText().toString())) {
                                    ContentValues contentValues = new ContentValues();
                                    contentValues.put("album_id", et2.getText().toString());
                                    contentValues.put("song_id", et3.getText().toString());
                                    getContentResolver().insert(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                            + tables[(int)TABLE_NAME_ID]), contentValues);
                                    break;
                                } else break;

                            case "update":
                                if (sp_tables.getSelectedItem().toString().equals("Albums")){
                                    if (idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/album" + "/" + et_id.getText().toString())) {
                                        ContentValues contentValues = new ContentValues();
                                        contentValues.put("id", et_id.getText().toString());
                                        contentValues.put("name", et2.getText().toString());
                                        contentValues.put("release", et3.getText().toString());
                                        getContentResolver().update(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                                + tables[(int)TABLE_NAME_ID] + "/" + et_id.getText().toString()), contentValues, null, null);
                                        break;
                                    }
                                }
                                   else if (sp_tables.getSelectedItem().toString().equals("Songs")) {
                                    if (idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/song" + "/" + et_id.getText().toString())) {
                                        ContentValues contentValues = new ContentValues();
                                        contentValues.put("id", et_id.getText().toString());
                                        contentValues.put("name", et2.getText().toString());
                                        contentValues.put("duration", et3.getText().toString());
                                        getContentResolver().update(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                                + tables[(int)TABLE_NAME_ID] + "/" + et_id.getText().toString()), contentValues, null, null);
                                        break;
                                    }

                                }  else if (sp_tables.getSelectedItem().toString().equals("AlbumSongs")){
                                    if (idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/albumsong" + "/" + et_id.getText().toString())) {
                                        if (idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/album" + "/" + et2.getText().toString())
                                                && idExistsInDatabase("content://com.elegion.roomdatabase.musicprovider/song" + "/" + et3.getText().toString())) {
                                            ContentValues contentValues = new ContentValues();
                                            contentValues.put("album_id", et2.getText().toString());
                                            contentValues.put("song_id", et3.getText().toString());
                                            getContentResolver().update(Uri.parse("content://com.elegion.roomdatabase.musicprovider/"
                                                    + tables[(int)TABLE_NAME_ID] + "/" + et_id.getText().toString()), contentValues, null, null);
                                            break;
                                        }
                                    }
                                }

                            case "delete":

                                    getContentResolver().delete(Uri.parse("content://com.elegion.roomdatabase.musicprovider/" +
                                            tables[(int)TABLE_NAME_ID] + "/" + et_id.getText().toString()), null,null);
                                    break;

                        }
                } else Toast.makeText(getApplicationContext(), "Ошибка ID!", Toast.LENGTH_SHORT).show();

            }
        });


    }

    //проверяем, есть ли вообще такие id

    private boolean idExistsInDatabase(String uri) {
        Cursor c = getContentResolver().query(Uri.parse(uri), null, null, null, null);

        if (c != null && c.moveToFirst()) {
            return true;
        } else {
            Toast.makeText(getApplicationContext(), "Ошибка ID!", Toast.LENGTH_SHORT).show();
            return false;
        }

    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new CursorLoader(this,
                Uri.parse("content://com.elegion.roomdatabase.musicprovider/" + args.getString(LOADER_TABLE_NAME)),
                null,
                "id" + " = " + args.getString(ID),
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null && data.moveToFirst()) {

            StringBuilder builder = new StringBuilder();
            do {
                builder.append(data.getString(1)).append(", ").append(data.getString(2)).append("\n");
            } while (data.moveToNext());
            QUERY_FROM_TABLE = builder.toString();
            Toast.makeText(getApplicationContext(), QUERY_FROM_TABLE, Toast.LENGTH_LONG).show();
        }// else Toast.makeText(getApplicationContext(), "ERROR", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onLoaderReset(Loader loader) {

    }
}
