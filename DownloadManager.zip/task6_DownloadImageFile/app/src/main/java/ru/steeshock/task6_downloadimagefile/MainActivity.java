package ru.steeshock.task6_downloadimagefile;

import android.Manifest;
import android.app.DownloadManager;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MyLog";
    private EditText mEditText;
    private Button mButtonDownload, mButtonShow;
    private ImageView mImageView;
    private DownloadManager mDownloadManager;
    public static String FILENAME = "";
    public static final String IMAGE_URL = "\\.jpg$|\\.bmp$|\\.jpeg$|\\.png$"; //добавил .jpg, потому что большинство файлов все-таки в этом формате

    public static final int WRITE_PERMISSION_RC = 1;
    private static String URL;
    private Uri Download_Uri;
    private long refid;

    ArrayList<Long> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDownloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

        mEditText = findViewById(R.id.et_url);
        mButtonDownload = findViewById(R.id.btn_download);
        mButtonShow = findViewById(R.id.btn_show);
        mImageView = findViewById(R.id.image);

        registerReceiver(onComplete,
                new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            if (!isPermissionsGranted()){
                requestAllPermissions();
            }

        mButtonDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isPermissionsGranted()) {
                    if (isFieldEmpty()) {
                        Toast.makeText(MainActivity.this, R.string.error_empty, Toast.LENGTH_SHORT).show();
                    } else if (isFieldValid()) {
                        if (isUrlCorrect()){
                            downloadImage();
                        } else Toast.makeText(MainActivity.this, R.string.error_image_url, Toast.LENGTH_SHORT).show();
                    } else Toast.makeText(MainActivity.this, R.string.error_valid, Toast.LENGTH_SHORT).show();
                } else {
                    requestAllPermissions();
                }
                

            }
        });

        mButtonShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mImageView.setImageURI(Uri.parse(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + FILENAME));

            }
        });

    }

    private void downloadImage() {

        Download_Uri = Uri.parse(mEditText.getText().toString());

        FILENAME = UUID.randomUUID().toString();

        DownloadManager.Request request = new DownloadManager.Request(Download_Uri);
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
        request.setAllowedOverRoaming(false);
        request.setTitle("GadgetSaint Downloading " + "Sample" + ".png");
        request.setDescription("Downloading " + "Sample" + ".png");
        request.setVisibleInDownloadsUi(true);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/" + FILENAME);


        refid = mDownloadManager.enqueue(request);
        list.add(refid);

    }

    private boolean isFieldEmpty() {
        return TextUtils.isEmpty(mEditText.getText().toString());
    }

    private boolean isFieldValid() {
        return Patterns.WEB_URL.matcher(mEditText.getText()).matches();
    }

    private boolean isUrlCorrect() {

        Pattern p = Pattern.compile(IMAGE_URL);
        Matcher m = p.matcher(mEditText.getText().toString());

        return m.find();
    }

    private void requestAllPermissions() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            new AlertDialog.Builder(this)
                    .setMessage("Без разрешений программа не будет работать должным образом")
                    .setPositiveButton("Понятно", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_PERMISSION_RC);
                        }
                    })
                    .show();

        } else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_PERMISSION_RC);
        }

    }

    private boolean isPermissionsGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }




    BroadcastReceiver onComplete = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {

            long referenceId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            list.remove(referenceId);

            if (list.isEmpty())
            {
                mButtonShow.setEnabled(true);
                Toast.makeText(context, "downloads complete", Toast.LENGTH_SHORT).show();
            }

        }
    };
}
