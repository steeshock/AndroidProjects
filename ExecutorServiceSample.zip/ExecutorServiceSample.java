
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.locks.ReentrantLock;

/* Привет! Если есть ошибки или замечания - напиши мне в телеграм (мой ник @steeshock)

   Заранее благодарен за кодревью! :)*/

public class ExecutorServiceSample {
	
    private static int mCount = 0;
    private static int mThreads = 4;
    private static int mStages = 100;
	
	public static ExecutorService executorService= Executors.newFixedThreadPool(mThreads);

	public static ReentrantLock locker = new ReentrantLock();

    public static void main(String[] args) throws InterruptedException, ExecutionException{
        for (int x = 0; x < mStages; x++) {
        	Future <Integer> future = executorService.submit(new Callable <Integer>() {
                @Override
                public Integer call() throws Exception {              	
                	int localCount = 0;            	
                    for (int y = 0; y < 1000; y++) {
                    	localCount++;  //local stage counter 
                    	//TimeUnit.MILLISECONDS.sleep(10);
                    }
                    return localCount;
                }
            });
        	locker.lock();
            mCount+=future.get(); //synchronized incrementing global counter
            locker.unlock();

        }

        System.out.println (mCount);
    }

}