package ru.steeshock.task4_heterogenousrecyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ru.steeshock.task4_heterogenousrecyclerview.models.Image;
import ru.steeshock.task4_heterogenousrecyclerview.models.Joke;

/**
 * Created by steeshock on 08.05.2018.
 */

public class ComplexAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    public static final String [] jokesCollection = {

        "Маленький мальчик по крыше гулял,\n" +
                "С крыши свалился, мальчик упал-\n" +
                "А бедная катя, в то время гуляла\n" +
                "Не повезло, страховкою стала!",
        "Маленький мальчик триллер смотрел.\n" +
                "Там рыжий разбойник лысого съел.\n" +
                "Долго он плакал. Заснуть он не мог.\n" +
                "Очень ужасный мультфильм колобок.",
        "Маленький мальчик по крыше гулял,\n" +
                "ТУ-104 слегка обгонял.\n" +
                "Кончилась крыша — и мама потом\n" +
                "Долго мозги собирала совком.",
        "Мальчик на рельсах кабель пилил,\n" +
                "Вдруг, неожиданно дождик полил.\n" +
                "Нет, он не станет теперь моряком,\n" +
                "Стал он отличным проводником.",
        "Маленький мальчик в подвале ходил\n" +
                "Разные кранчики сдуру крутил\n" +
                "Мощный фонтан и крутой кипяток\n" +
                "Вынесли сваренный мяса кусок.",
        "Маленький мальчик по стройке гулял,\n" +
                "Песни Киркорова он напевал,\n" +
                "Каток намотал попсовое тело,\n" +
                "Рокер — каменщик знал своё дело.",
        "Маленький мальчик по крыше гулял\n" +
                "Маленький мальчик с крыши упал.\n" +
                "Сделал он в воздухе 33 сальта,\n" +
                "Долго его соскребали с асфальта.",
        "Маленький мальчик землянку копал\n" +
                "Железку нашёл, об кирпич постучал…\n" +
                "Ноги — на ёлке, руки — под дубом…\n" +
                "С миной нельзя обращаться так грубо!",
        "Маленький мальчик водку купил,\n" +
                "И перед папой бутылку разбил.\n" +
                "Крики и драка, семейная ссора,\n" +
                "Так вот и вырос доктор Майоров.",
        "Маленький мальчик по лесу гулял\n" +
                "Длинненьким хоботом птичек пугал,\n" +
                "После копытами в лужу залез,\n" +
                "Тихо качался Чернобыльский лес.",
        "Маленький мальчик гранату нашел,\n" +
                "С ней он спокойно до дому дошел.\n" +
                "Но захотелось гранату вдруг съесть,\n" +
                "Челюсть нашли километров за шесть.",
        "Маленький мальчик на крыше сидел,\n" +
                "Был бы он бабочкой, он полетел.\n" +
                "Сзади подкрался с дубиною кто-то —\n" +
                "Вот и сбылась мечта идиота!"

    };

    public static final int [] imagesCollection = {
            R.drawable.mem1,
            R.drawable.mem2,
            R.drawable.mem3,
            R.drawable.mem4,
            R.drawable.mem5,
            R.drawable.mem6,
            R.drawable.mem7,
            R.drawable.mem8,
            R.drawable.mem9,
            R.drawable.mem10,

    };

    private static final List<Object> mList = new ArrayList<>(); //держим переменную наших данных и сразу инициализируем


    private Random mRandom = new Random();

    private final static int JOKE_VIEW = 0;
    private final static int IMAGE_VIEW = 1;

    public ComplexAdapter() {
        int count = mRandom.nextInt(9);
        mList.add(new Joke("Стишок #" + String.valueOf(getItemCount()+1), jokesCollection[count]));
        mList.add(new Image(imagesCollection[count]));
        }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder viewHolder;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        switch (viewType) {
            case JOKE_VIEW:
                View view1 = inflater.inflate(R.layout.li_joke, parent, false);
                viewHolder = new JokeHolder(view1);
                break;

            case IMAGE_VIEW:
                View view2 = inflater.inflate(R.layout.li_image, parent, false);
                viewHolder = new ImageHolder(view2);
                break;

            default:
                View view3 = inflater.inflate(R.layout.li_joke, parent, false);
                viewHolder = new JokeHolder(view3); break;
        }

        return viewHolder;
    }

    @Override
    public int getItemViewType(int position) {

        if (mList.get(position) instanceof Joke) {
            return JOKE_VIEW;
        } else if (mList.get(position) instanceof Image) {
            return IMAGE_VIEW;
        }
        return -1;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {


        switch (holder.getItemViewType()) {
            case JOKE_VIEW:
                JokeHolder vh1 = (JokeHolder) holder;
                vh1.bind((Joke)mList.get(position));
                break;
            case IMAGE_VIEW:
                ImageHolder vh2 = (ImageHolder) holder;
                vh2.bind((Image)mList.get(position));
                break;

        }
        
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // при нажатии на элемент, удаляем его из списка и обЪявляем об этом

                mList.remove(position);
                notifyDataSetChanged();

            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public void addOneJoke() {

        // при нажатии на кнопку на тулбаре, добавляем одну запись

        int count = mRandom.nextInt(jokesCollection.length);
        mList.add(new Joke("Стишок #" + String.valueOf(getItemCount()+1), jokesCollection[count]));
        notifyDataSetChanged();
    }

    public void addOneMeme() {

        // при нажатии на кнопку на тулбаре, добавляем одну запись

        int count = mRandom.nextInt(imagesCollection.length);
        mList.add(new Image(imagesCollection[count]));
        notifyDataSetChanged();
    }


}
