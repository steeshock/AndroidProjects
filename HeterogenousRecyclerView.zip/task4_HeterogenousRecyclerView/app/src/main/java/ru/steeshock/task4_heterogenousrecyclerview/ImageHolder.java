package ru.steeshock.task4_heterogenousrecyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import ru.steeshock.task4_heterogenousrecyclerview.models.Image;

/**
 * Created by steeshock on 09.05.2018.
 */

public class ImageHolder extends RecyclerView.ViewHolder {

    private ImageView mImageView;


    public ImageHolder(View itemView) {
        super(itemView);

        mImageView = itemView.findViewById(R.id.image);
    }

    public void bind(Image image) {

        mImageView.setImageResource(image.getPath());

    }
}
