package ru.steeshock.task4_heterogenousrecyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import ru.steeshock.task4_heterogenousrecyclerview.models.Joke;

/**
 * Created by steeshock on 08.05.2018.
 */

public class JokeHolder extends RecyclerView.ViewHolder{

    private TextView tvTitle;
    private TextView tvArticle;



    public JokeHolder(final View itemView) {
        super(itemView);

        tvTitle = itemView.findViewById(R.id.tvTitle);
        tvArticle = itemView.findViewById(R.id.tvArticle);



    }

    public void bind(Joke joke) {

        tvTitle.setText(joke.getTitle());
        tvArticle.setText(joke.getArticle());

    }

}
