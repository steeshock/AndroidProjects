package ru.steeshock.task4_heterogenousrecyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    private RecyclerView mRecyclerView;
    private static final ComplexAdapter M_COMPLEX_ADAPTER = new ComplexAdapter();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mRecyclerView = findViewById(R.id.recycler);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(M_COMPLEX_ADAPTER);

    }

    @Override
    protected void onResume() {
        super.onResume();
        mRecyclerView.scrollToPosition(M_COMPLEX_ADAPTER.getItemCount() - 1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.action_joke:
                M_COMPLEX_ADAPTER.addOneJoke();
                mRecyclerView.scrollToPosition(M_COMPLEX_ADAPTER.getItemCount() - 1); // двигаем до последней позиции
                break;

            case R.id.action_image:
                M_COMPLEX_ADAPTER.addOneMeme();
                mRecyclerView.scrollToPosition(M_COMPLEX_ADAPTER.getItemCount() - 1); // двигаем до последней позиции
            default: break;
        }

        return super.onOptionsItemSelected(item);

    }
}
