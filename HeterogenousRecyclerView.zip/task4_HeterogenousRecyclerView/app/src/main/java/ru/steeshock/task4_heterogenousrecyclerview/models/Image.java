package ru.steeshock.task4_heterogenousrecyclerview.models;

/**
 * Created by steeshock on 09.05.2018.
 */

public class Image {

    private int mPath;

    public Image(int path) {
        mPath = path;
    }

    public int getPath() {
        return mPath;
    }

    public void setPath(int path) {
        mPath = path;
    }
}
