package ru.steeshock.task4_heterogenousrecyclerview.models;

/**
 * Created by steeshock on 08.05.2018.
 */

public class Joke {

    private String mTitle;
    private String mArticle;


    public Joke(String title, String article) {
        mTitle = title;
        mArticle = article;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getArticle() {
        return mArticle;
    }

    public void setArticle(String article) {
        mArticle = article;
    }







}
