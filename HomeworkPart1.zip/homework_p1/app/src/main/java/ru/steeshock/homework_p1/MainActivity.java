package ru.steeshock.homework_p1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText txtField;
    private Button btnEnter;


    private View.OnClickListener onEnterClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (!TextUtils.isEmpty(txtField.getText())){
                ShowToast();
                Intent startSecondActivity = new Intent(MainActivity.this, SecondActivity.class);
                startSecondActivity.putExtra(SecondActivity.INFO, txtField.getText().toString());
                startActivity(startSecondActivity);

            }
        }
    };

    private void ShowToast () {

        Toast.makeText(this, txtField.getText(), Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txtField = findViewById(R.id.field);
        btnEnter = findViewById(R.id.btnFirst);

        btnEnter.setOnClickListener(onEnterClickListener);
    }
}

