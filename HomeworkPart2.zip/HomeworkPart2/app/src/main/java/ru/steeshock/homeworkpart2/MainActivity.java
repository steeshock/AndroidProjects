package ru.steeshock.homeworkpart2;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    MainFragment mainFrag = new MainFragment();
    SettingsFragment settFrag = new SettingsFragment();
    SearchFragment searchFrag = new SearchFragment();

    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, mainFrag)
                .addToBackStack(MainFragment.class.getName())
                .commit();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.itSettings:
                showSettings();
                Toast.makeText(this, R.string.settings, Toast.LENGTH_SHORT).show();break;
            case R.id.itSearch:
                showSearch();
                Toast.makeText(this, R.string.search, Toast.LENGTH_SHORT).show();break;
            case R.id.itExit:
                finish();
                Toast.makeText(this, R.string.exit, Toast.LENGTH_SHORT).show();break;
                default: break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void showSettings () {
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, settFrag)
                .addToBackStack(SettingsFragment.class.getName())
                .commit();
    }

    public void showSearch () {
        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, searchFrag)
                .addToBackStack(SearchFragment.class.getName())
                .commit();
    }
}
