package ru.steeshock.homeworkpart2;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class SearchFragment extends Fragment {

    EditText textForSearch;
    Button btnSearch;

    private SharedPreferences mSharedPreferences;

    private View.OnClickListener onSearchClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent goSearch = new Intent (Intent.ACTION_WEB_SEARCH);
            goSearch.putExtra(SearchManager.QUERY,
                    mSharedPreferences.getString(SettingsFragment.USER_CHOICE, "") + textForSearch.getText().toString());
            startActivity(goSearch);
        }
    };


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.search_fragment, container,false);

        mSharedPreferences = getActivity().getSharedPreferences(SettingsFragment.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        textForSearch = v.findViewById(R.id.txtEdit);
        btnSearch = v.findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(onSearchClickListener);

        return v;
    }







}
