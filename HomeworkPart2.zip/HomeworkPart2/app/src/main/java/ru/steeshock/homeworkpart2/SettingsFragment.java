package ru.steeshock.homeworkpart2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;



public class SettingsFragment extends Fragment {

    RadioGroup radioGroup;

    public static final String SHARED_PREF_NAME = "SHARED_PREF_NAME";
    public static final String USER_CHOICE = "USER_CHOICE";
    public static final String CHECKED_RADIO_BUTTON = "CHECKED_RADIO_BUTTON";
    private SharedPreferences mSharedPreferences;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.settings_fragment, container, false);
        radioGroup = v.findViewById(R.id.rGroup);
        mSharedPreferences = getActivity().getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);

        radioGroup.check(mSharedPreferences.getInt(CHECKED_RADIO_BUTTON, -1));

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rbGoogle:
                        mSharedPreferences.edit().putInt(CHECKED_RADIO_BUTTON, R.id.rbGoogle).apply();
                        mSharedPreferences.edit().putString(USER_CHOICE, "https://google.com/search?q=").apply();break;
                    case R.id.rbYandex:
                        mSharedPreferences.edit().putInt(CHECKED_RADIO_BUTTON, R.id.rbYandex).apply();
                        mSharedPreferences.edit().putString(USER_CHOICE, "https://yandex.ru/search/?text=").apply();break;
                    case R.id.rbBing:
                        mSharedPreferences.edit().putInt(CHECKED_RADIO_BUTTON, R.id.rbBing).apply();
                        mSharedPreferences.edit().putString(USER_CHOICE, "https://www.bing.com/search?q=").apply();break;
                }

            }
        });


        return v;
    }

}
