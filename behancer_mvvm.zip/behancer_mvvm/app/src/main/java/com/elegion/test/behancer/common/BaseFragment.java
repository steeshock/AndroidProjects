package com.elegion.test.behancer.common;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment {

    //фрагменты получаются разные, что сюда писать - не знаю :\
}
