package com.elegion.test.behancer.ui.userprojects;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.databinding.ObservableField;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.elegion.test.behancer.common.BaseFragment;
import com.elegion.test.behancer.data.Storage;
import com.elegion.test.behancer.databinding.UserProjectsBinding;
import com.elegion.test.behancer.ui.profile.ProfileFragment;
import com.elegion.test.behancer.ui.projects.ProjectsAdapter;
import com.elegion.test.behancer.utils.UserCustomFactory;


public class UserProjectsFragment extends BaseFragment {

    private UserProjectsViewModel mUserProjectsViewModel;

    private ProjectsAdapter.OnItemClickListener mOnItemClickListener;
    private ObservableField<String> mUsername = new ObservableField<>();

    public static Fragment newInstance(Bundle bundleExtra) {

        UserProjectsFragment fragment = new UserProjectsFragment();
        fragment.setArguments(bundleExtra);

        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Storage.StorageOwner) {
            Storage storage = ((Storage.StorageOwner) context).obtainStorage();
            if (getArguments() != null) {
                mUsername.set( getArguments().getString(ProfileFragment.PROFILE_KEY));
            }
            UserCustomFactory factory = new UserCustomFactory(storage, mOnItemClickListener, mUsername);
            mUserProjectsViewModel = ViewModelProviders.of(this, factory).get(UserProjectsViewModel.class);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        UserProjectsBinding binding =  UserProjectsBinding.inflate(inflater, container, false);
        binding.setVm(mUserProjectsViewModel);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

}
