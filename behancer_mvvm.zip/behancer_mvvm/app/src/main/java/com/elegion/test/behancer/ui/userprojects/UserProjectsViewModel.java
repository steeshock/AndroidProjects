package com.elegion.test.behancer.ui.userprojects;

import android.databinding.ObservableField;

import com.elegion.test.behancer.common.BaseViewModel;
import com.elegion.test.behancer.data.Storage;
import com.elegion.test.behancer.data.model.project.ProjectResponse;
import com.elegion.test.behancer.ui.projects.ProjectsAdapter;
import com.elegion.test.behancer.utils.ApiUtils;

import io.reactivex.schedulers.Schedulers;

public class UserProjectsViewModel extends BaseViewModel {


    private ObservableField<String> mUsername;
    public void setUsername(ObservableField<String> username) {
        mUsername = username;
    }

    public UserProjectsViewModel(Storage storage, ProjectsAdapter.OnItemClickListener onItemClickListener, ObservableField<String> username) {
        mStorage = storage;
        mUsername = username;
        mOnItemClickListener = onItemClickListener;
        mProjects = mStorage.getUserProjectsPaged(mUsername.get());
        updateProjects();

    }

    @Override
    public void updateProjects() {
        mDisposable = ApiUtils.getApiService().getUserProjects(mUsername.get())
                .map(ProjectResponse::getProjects)
                .doOnSubscribe(disposable -> mIsLoading.postValue(true))
                .doOnSuccess(response -> mIsErrorVisible.postValue(false))
                .doFinally(() -> mIsLoading.postValue(false))
                .subscribeOn(Schedulers.io())
                .subscribe(
                        response -> mStorage.insertProjects(response),
                        throwable -> {
                            mIsErrorVisible.postValue(true);
                            boolean value  = mProjects.getValue()==null || mProjects.getValue().size() == 0;
                            mIsErrorVisible.postValue(value);
                        });
    }
}
